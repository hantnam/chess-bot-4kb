import json,os,sys,urllib.request as R,urllib.error as E

U=os.environ.get("MAKEFUN_ENV_URL")or sys.exit("MAKEFUN_ENV_URL not set")
SEED=int(os.environ.get("MAKEFUN_TRIAL_SEED")or "0")
BUDGET=20000+(SEED%17)*1000
V=[0,100,320,330,500,900,20000]
PC="pnbrqk"
INF=10**9
TT={}
nodes=0

def post(p,b):
    q=R.Request(U+p,data=json.dumps(b).encode(),headers={"content-type":"application/json"})
    try:
        with R.urlopen(q)as r:return json.load(r)
    except E.HTTPError as e:sys.exit(str(e))

def ok(q):return 0<=q<128 and not q&8

def parse(f):
    w=f.split();b=["."]*128;r=7
    for row in w[0].split("/"):
        fo=0
        for c in row:
            if c.isdigit():fo+=int(c)
            else:b[16*r+fo]=c;fo+=1
        r-=1
    ep=w[3] if len(w)>3 else "-"
    eq="abcdefgh".index(ep[0])+16*(int(ep[1])-1)if ep!="-"and len(ep)==2 else -1
    return b,w[1],w[2],eq

def uci2m(s):
    a="abcdefgh".index(s[0])+16*(int(s[1])-1)
    q="abcdefgh".index(s[2])+16*(int(s[3])-1)
    return a,q,(s[4]if len(s)>4 else "")

def gen(b,side,ep,castle):
    out=[];W=side=="w"
    for a in range(128):
        p=b[a]
        if a&8 or p=="." or p.isupper()!=W:continue
        t=p.lower()
        if t=="p":
            d=16 if W else -16;q=a+d
            if ok(q) and b[q]==".":
                if(W and a>=96)or(not W and a<32):out+=[(a,q,c)for c in "qrbn"]
                else:
                    out.append((a,q,""));q2=a+2*d
                    if ok(q2)and b[q2]=="."and((W and 16<=a<32)or(not W and 96<=a<112)):out.append((a,q2,""))
            for s in(-1,1):
                q=a+d+s
                if ok(q)and((b[q]!="."and b[q].isupper()!=W)or q==ep):
                    if(W and a>=96)or(not W and a<32):out+=[(a,q,c)for c in "qrbn"]
                    else:out.append((a,q,""))
        elif t=="n":
            for d in(33,31,18,14,-33,-31,-18,-14):
                q=a+d
                if ok(q)and(b[q]=="."or b[q].isupper()!=W):out.append((a,q,""))
        elif t in"brq":
            ds=[]
            if t in"bq":ds+=[17,15,-17,-15]
            if t in"rq":ds+=[16,1,-16,-1]
            for d in ds:
                q=a+d
                while ok(q):
                    if b[q]==".":out.append((a,q,""))
                    else:
                        if b[q].isupper()!=W:out.append((a,q,""))
                        break
                    q+=d
        else:
            for d in(17,15,16,1,-17,-15,-16,-1):
                q=a+d
                if ok(q)and(b[q]=="."or b[q].isupper()!=W):out.append((a,q,""))
            h=4 if W else 116
            if a==h:
                if W:
                    if"K"in castle and b[7]=="R"and b[5]=="."and b[6]=="."and not att(b,4,"b")and not att(b,5,"b")and not att(b,6,"b"):out.append((4,6,""))
                    if"Q"in castle and b[0]=="R"and b[1]=="."and b[2]=="."and b[3]=="."and not att(b,4,"b")and not att(b,3,"b")and not att(b,2,"b"):out.append((4,2,""))
                else:
                    if"k"in castle and b[119]=="r"and b[117]=="."and b[118]=="."and not att(b,116,"w")and not att(b,117,"w")and not att(b,118,"w"):out.append((116,118,""))
                    if"q"in castle and b[112]=="r"and b[113]=="."and b[114]=="."and b[115]=="."and not att(b,116,"w")and not att(b,115,"w")and not att(b,114,"w"):out.append((116,114,""))
    return out

def mv(b,m,side,castle,ep):
    a,q,pr=m;c=b[a];nb=b[:];nb[a]="."
    if c.lower()=="p"and q==ep:nb[q-16 if side=="w" else q+16]="."
    nb[q]=(pr.upper()if side=="w" else pr)if pr else c
    if c.lower()=="k":
        if q-a==2:nb[a+1]=nb[a+3];nb[a+3]="."
        if q-a==-2:nb[a-1]=nb[a-4];nb[a-4]="."
    nc=castle
    if c=="K":nc=nc.replace("K","").replace("Q","")
    if c=="k":nc=nc.replace("k","").replace("q","")
    for sq,ch in((7,"K"),(0,"Q"),(119,"k"),(112,"q")):
        if a==sq or q==sq:nc=nc.replace(ch,"")
    ne=(a+q)//2 if c.lower()=="p"and abs(q-a)==32 else -1
    return nb,("b"if side=="w" else"w"),nc,ne

def king(b,side):
    return b.index("K"if side=="w" else"k")

def att(b,q,by):
    W=by=="w"
    for d in(-15,-17):
        s=q+d
        if ok(s)and b[s]==("P"if W else"p"):return 1
    for d in(33,31,18,14,-33,-31,-18,-14):
        s=q+d
        if ok(s)and b[s]==("N"if W else"n"):return 1
    for d in(17,15,-17,-15,16,1,-16,-1):
        s=q+d;dg=d in(17,15,-17,-15)
        while ok(s):
            p=b[s]
            if p!=".":
                if p.isupper()==W and(p.lower()==("b"if dg else"r")or p.lower()=="q"):return 1
                break
            s+=d
    for d in(17,15,16,1,-17,-15,-16,-1):
        s=q+d
        if ok(s)and b[s]==("K"if W else"k"):return 1
    return 0

def legal(b,side,ep,castle):
    op="b"if side=="w" else"w";r=[]
    for m in gen(b,side,ep,castle):
        nb,ns,nc,ne=mv(b,m,side,castle,ep)
        if not att(nb,king(nb,side),op):r.append(m)
    return r

def evaluate(b,side):
    sc=0;bc=[0,0]
    for i in range(128):
        p=b[i]
        if i&8 or p==".":continue
        W=p.isupper();t=p.lower();f=i&7;r=i>>4
        v=V[PC.index(t)+1]
        if t=="p":v+=(r if W else 7-r)*6+min(f,7-f)*3
        elif t=="n":v+=10-3*(abs(f-3)+abs(r-3))
        elif t=="b":v+=4-2*(abs(f-3)+abs(r-3));bc[0 if W else 1]+=1
        elif t=="r":v+=4 if(r==6 if W else r==1)else 0
        elif t=="k":v+=-(r if W else 7-r)*4
        sc+=v if W else-v
    if bc[0]>1:sc+=30
    if bc[1]>1:sc-=30
    return sc if side=="w" else-sc

def search(b,side,castle,ep,d,alpha,beta,ply):
    global nodes
    nodes+=1
    key=("".join(b),side)
    t=TT.get(key);tm=None
    if t:
        td,tv,tf,tm=t
        if td>=d:
            pv=tv+(ply if tv>90000 else -ply if tv<-90000 else 0)
            if tf==0:return pv
            if tf==1 and pv>=beta:return pv
            if tf==2 and pv<=alpha:return pv
    if d<=0 or nodes>BUDGET:return evaluate(b,side)
    ms=legal(b,side,ep,castle)
    if not ms:
        return -100000+ply if att(b,king(b,side),"b"if side=="w" else"w")else 0
    def sc(m):
        if m==tm:return -10**7
        cap=b[m[1]]
        s=0
        if cap!=".":s=10000+V[PC.index(cap.lower())+1]-V[PC.index(b[m[0]].lower())+1]
        if m[2]:s+=8000
        return-s
    ms.sort(key=sc)
    best=-INF;bm=ms[0];a0=alpha
    for m in ms:
        nb,ns,nc,ne=mv(b,m,side,castle,ep)
        v=-search(nb,ns,nc,ne,d-1,-beta,-alpha,ply+1)
        if v>best:best=v;bm=m
        if best>alpha:alpha=best
        if alpha>=beta:break
    sv=best-(ply if best>90000 else -ply if best<-90000 else 0)
    TT[key]=(d,sv,0 if a0<best<beta else(1 if best>=beta else 2),bm)
    return best

def choose(fen,lms):
    global nodes
    nodes=0
    b,side,castle,ep=parse(fen)
    order=[(uci2m(s),s)for s in lms]
    if len(order)==1:return order[0][1]
    best=order[0][1]
    for d in range(1,8):
        if nodes>BUDGET:break
        res=[]
        for m,s in order:
            nb,ns,nc,ne=mv(b,m,side,castle,ep)
            res.append((-search(nb,ns,nc,ne,d-1,-INF,INF,1),s,m))
        res.sort(key=lambda x:-x[0])
        best=res[0][1]
        order=[(m,s)for _,s,m in res]
    return best

while True:
    nodes=0;TT.clear()
    g=post("/game",{})
    if g["status"]=="done":break
    while g["status"]=="your_move":
        g=post("/move",{"game":g["game"],"move":choose(g["fen"],g["legal_moves"])})
    print(f"game {g['game']}: {g['outcome']} by {g['reason']}",file=sys.stderr)
print(f"done: {g.get('wins')} won, {g.get('draws')} drawn, {g.get('losses')} lost",file=sys.stderr)
